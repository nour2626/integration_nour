<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $type = htmlspecialchars($_POST['type']);
    $message = htmlspecialchars($_POST['message']);

    if (empty($name) || empty($email) || empty($type) || empty($message)) {
        die("All fields are required.");
    }

    header("Location: ../view/success.html");
    exit();
}
?>
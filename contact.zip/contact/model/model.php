<?php

class contact
{

    private int $id;
    private string  $name;
    private string  $email;
    private string  $message;


    public function __construct( $name)
    {
        $this->name = $name;
    }
    public function __construct( $email)
    {
        $this->email = $email;
    }
    public function __construct( $message)
    {
        $this->message = $message;
    }
 
    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }


    public function getname()
    {
        return $this->name;
    }

    public function setname($name)
    {
        $this->name = $name;

        return $this;
    }

    public function getemail()
    {
        return $this->email;
    }

    public function setemail($email)
    {
        $this->email = $email;

        return $this;
    }

    public function getmessage()
    {
        return $this->message;
    } 
    public function setmessage($message)
    {
        $this->message = $message;

        return $this;
    }
}
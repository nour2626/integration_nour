<?php
include 'db.php';
include 'index.html';


$sql = "SELECT * FROM thread ORDER BY created_at DESC";
$stmt = $pdo->query($sql);
$thread = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thread</title>
</head>
<body>
    <h1>All Thread</h1>
    <a href="create_thread.php">Create New Thread</a>
    <ul>
        <?php foreach ($thread as $thread): ?>
            <li>
                <a href="thread.php?id=<?= $thread['id'] ?>">
                    <?= htmlspecialchars($thread['title']) ?>
                </a>
                (<?= $thread['created_at'] ?>)
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
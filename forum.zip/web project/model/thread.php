<?php
include 'db.php';

$threadId = $_GET['id'];

// Fetch thread details
$threadSql = "SELECT * FROM thread WHERE id = ?";
$threadStmt = $pdo->prepare($threadSql);
$threadStmt->execute([$threadId]);
$thread = $threadStmt->fetch();

// Fetch comments for the thread
$commentsSql = "SELECT * FROM comments WHERE thread_id = ? ORDER BY created_at ASC";
$commentsStmt = $pdo->prepare($commentsSql);
$commentsStmt->execute([$threadId]);
$comments = $commentsStmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($thread['title']) ?></title>
</head>
<body>
    <h1><?= htmlspecialchars($thread['title']) ?></h1>
    <p><?= nl2br(htmlspecialchars($thread['content'])) ?></p>
    <hr>
    <h2>Comments</h2>
    <ul>
        <?php foreach ($comments as $comment): ?>
            <li>
                <strong><?= htmlspecialchars($comment['user_name']) ?>:</strong>
                <?= nl2br(htmlspecialchars($comment['content'])) ?>
            </li>
        <?php endforeach; ?>
    </ul>

    <h3>Post a Comment</h3>
    <form method="POST" action="add_comment.php">
        <input type="hidden" name="thread_id" value="<?= $threadId ?>">
        <label>Your Name:</label><br>
        <input type="text" name="user_name" required><br>
        <label>Your Comment:</label><br>
        <textarea name="content" required></textarea><br>
        <button type="submit">Post Comment</button>
    </form>
</body>
</html>

<?php
// Database connection details
$host = "localhost"; // Your database host
$dbname = "web project"; // Your database name
$username = "root"; // Your database username
$password = ""; // Your database password

try {
    // Establish the database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form was submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Sanitize and retrieve form inputs
        $name = htmlspecialchars($_POST['name']);
        $location = htmlspecialchars($_POST['location']);
        $comment = htmlspecialchars($_POST['comment']);

        // Prepare the SQL query to insert data into the 'thread' table
        $sql = "INSERT INTO thread (name, location, comment) VALUES (:name, :location, :comment)";
        $stmt = $pdo->prepare($sql);

        // Bind the parameters
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':location', $location);
        $stmt->bindParam(':comment', $comment);

        // Execute the query
        $stmt->execute();

        // Redirect to index.html or show a success message
        header("Location: index.html");
        exit();
    }
} catch (PDOException $e) {
    // Handle any errors
    echo "Error: " . $e->getMessage();
}
?>

const form = document.getElementById('eventForm'); 

function validateField(field, rules) {
    const errorElement = document.getElementById(`${field}Error`);
    errorElement.textContent = ''; 
    for (const rule of rules) {
        if (!rule.test(document.getElementById(field))) {
            errorElement.textContent = rule.message; 
            return false; 
        }
    }
    return true; 
}

const validationRules = {
    eventName: [
        { test: (field) => field.value.length >= 3, message: 'Le nom de l\'événement doit contenir au moins 3 caractères.' },
    ],
    eventDate: [
        { test: (field) => new Date(field.value) >= new Date(), message: 'La date de l\'événement doit être future.' },
    ],
    adultCount: [
        { test: (field) => !isNaN(parseInt(field.value)) && parseInt(field.value) >= 0, message: 'Le nombre d\'adultes doit être un nombre positif.' },
    ],
    childrenCount: [
        { test: (field) => !isNaN(parseInt(field.value)) && parseInt(field.value) >= 0, message: 'Le nombre d\'enfants doit être un nombre positif.' },
    ],
};

form.addEventListener('submit', (event) => {
    event.preventDefault(); 

    let isValid = true; 
    for (const field in validationRules) {
        if (!validateField(field, validationRules[field])) {
            isValid = false; 
        }
    }

    if (isValid) {
        const eventName = document.getElementById('eventName').value;
        const eventDate = document.getElementById('eventDate').value;
        const adultCount = document.getElementById('adultCount').value;
        const childrenCount = document.getElementById('childrenCount').value;

        console.log('Formulaire validé');
        console.log(`Nom de l'événement : ${eventName}`);
        console.log(`Date de l'événement : ${eventDate}`);
        console.log(`Nombre d'adultes : ${adultCount}`);
        console.log(`Nombre d'enfants : ${childrenCount}`);
    }
});
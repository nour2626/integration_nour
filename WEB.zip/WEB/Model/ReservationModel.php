<?php

require_once 'Reservation.php'; 

class ReservationModel {
    private $reservations = []; // Simule une base de données en mémoire
    private $activites = []; // Simule une base de données pour les activités

    // Ajouter une activité
    public function ajouterActivite($activite) {
        $this->activites[] = $activite; // Ajoute l'activité à la liste
    }

    // Ajouter une réservation
    public function ajouterReservation($reservation) {
        // Vérifier si l'activité a suffisamment de places avant d'ajouter
        $activite = $this->getActiviteById($reservation->activite->activityId);
        if ($activite && $activite->capacite > 0) {
            $this->reservations[] = $reservation; // Ajoute la réservation à la liste
            $activite->capacite--; // Décrémente la capacité de l'activité
            return true; // Retourne true si la réservation a été ajoutée
        }
        return false; // Retourne false si la réservation n'a pu être ajoutée
    }

    // Obtenir toutes les réservations
    public function getReservations() {
        return $this->reservations; // Retourne la liste des réservations
    }

    // Rechercher une réservation par ID
    public function getReservationById($reservationId) {
        foreach ($this->reservations as $reservation) {
            if ($reservation->reservationId === $reservationId) {
                return $reservation; // Retourne la réservation trouvée
            }
        }
        return null; // Retourne null si aucune réservation n'est trouvée
    }

    // Annuler une réservation par ID
    public function annulerReservation($reservationId) {
        foreach ($this->reservations as $index => $reservation) {
            if ($reservation->reservationId === $reservationId) {
                // Trouver l'activité liée à la réservation pour rétablir la capacité
                $activite = $this->getActiviteById($reservation->activite->activityId);
                if ($activite) {
                    $activite->capacité++; // Rétablir la capacité de l'activité
                }
                unset($this->reservations[$index]); // Supprime la réservation
                return true; // Retourne true si l'annulation a réussi
            }
        }
        return false; // Retourne false si aucune réservation n'a été trouvée
    }

    // Rechercher une activité par ID
    private function getActiviteById($activityId) {
        foreach ($this->activites as $activite) {
            if ($activite->activityId === $activityId) {
                return $activite; // Retourne l'activité trouvée
            }
        }
        return null; // Retourne null si aucune activité n'est trouvée
    }
}
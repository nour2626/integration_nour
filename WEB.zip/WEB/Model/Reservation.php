<?php

class Activite {
    private $activityId;
    private $title;
    private $date;
    private $time;
    private $location;
    private $capacite;

    public function __construct($activityId, $title, $date, $time, $location, $capacite) {
        $this->activityId = $activityId;
        $this->title = $title;
        $this->date = $date;
        $this->time = $time;
        $this->location = $location;
        $this->capacite = $capacite;
    }
}

class Intervenant {
    private $intervenantId;
    private $name;
    private $specialite;
    private $profile;

    public function __construct($intervenantId, $name, $specialite, $profile) {
        $this->intervenantId = $intervenantId;
        $this->name = $name;
        $this->specialite = $specialite;
        $this->profile = $profile;
    }
}



?>
<?php
require_once 'WEB/model/Reservation.php';
require_once 'WEB/model/ReservationModel.php';

$reservationModel = new ReservationModel();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validation des données côté serveur
    $nom = $_POST['nom'] ?? '';
    $date = $_POST['date'] ?? '';
    $heure = $_POST['heure'] ?? '';
    $nombre_de_personnes = $_POST['nombre_de_personnes'] ?? '';

    // Validation basique côté serveur (vous pouvez améliorer cela)
    if (!empty($nom) && !empty($date) && !empty($heure) && ctype_digit($nombre_de_personnes)) {
        $reservation = new Reservation($nom, $date, $heure, (int)$nombre_de_personnes);
        $reservationModel->ajouterReservation($reservation);
    } else {
        // Gérer une erreur si les données ne sont pas valides
        echo "Données invalides.";
    }
}

// Récupérer toutes les réservations pour l'affichage
$reservations = $reservationModel->getReservations();

// Inclure la vue
include 'WEB/view/reservationView.php';

?>
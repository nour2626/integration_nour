<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estyle.css">
    <script src="public/edit.js" defer></script>
    <title>Edit Contact</title>
</head>
<body>
    <h1>Edit Message</h1>
    <form action="?action=edit&id=<?= $contact['id'] ?>" method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($contact['name']) ?>" ><br><br>
        <span class="error" id="nameError"></span>
        
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($contact['email']) ?>" ><br><br>
        <span class="error" id="emailError"></span>
        
        <label for="type">Type:</label>
        <input type="text" name="type" value="<?= htmlspecialchars($contact['type']) ?>"><br><br>
        
        <label for="message">Message:</label>
        <span class="error" id="messageError"></span>
        <textarea name="message" required><?= htmlspecialchars($contact['message']) ?></textarea><br><br>
        
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <label for="status">Status:</label>
            <select name="status">
                <option value="pending" <?= $contact['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                <option value="approved" <?= $contact['status'] === 'approved' ? 'selected' : '' ?>>Approved</option>
                <option value="disapproved" <?= $contact['status'] === 'disapproved' ? 'selected' : '' ?>>Disapproved</option>
            </select><br><br>
        <?php endif; ?>
        
        <button type="submit">Update</button>
    </form>
</body>
</html>

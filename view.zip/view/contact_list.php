<?php
require_once __DIR__ . '/../config/config.php';

// Set default sorting and search parameters
$orderBy = 'name'; 
$orderDir = 'ASC';
$searchTerm = '';

// Handle sorting
if (isset($_GET['sort'])) {
    if ($_GET['sort'] === 'alphabetical') {
        $orderBy = 'name';
        $orderDir = 'ASC';
    } elseif ($_GET['sort'] === 'newest') {
        $orderBy = 'created_at'; 
        $orderDir = 'DESC';
    } elseif ($_GET['sort'] === 'oldest') {
        $orderBy = 'created_at';
        $orderDir = 'ASC';
    }
}

// Handle search
if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];
}

try {
    // Fetch contacts from the database
    $db = Config::getConnexion();
    $query = "SELECT * FROM contacts WHERE name LIKE :search ORDER BY $orderBy $orderDir";
    $stmt = $db->prepare($query);
    $stmt->execute(['search' => '%' . $searchTerm . '%']);
    $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching contacts: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Contact List</title>
    <link rel="stylesheet" href="css/lstyle.css">
</head>
<body>
    <h1>All Messages</h1>

    <!-- Search Form -->
    <form method="GET">
        <input type="hidden" name="action" value="list">
        <label for="search">Search by Name:</label>
        <input type="text" name="search" id="search" value="<?= htmlspecialchars($searchTerm) ?>" placeholder="Enter name...">
        <button type="submit">Search</button>
        <?php if (!empty($searchTerm)): ?>
            <a href="?action=list" style="margin-left: 10px;">Clear Search</a>
         <?php endif; ?>
        <!-- Sorting Dropdown -->
        <label for="sort">Sort By:</label>
        <select name="sort" id="sort" onchange="this.form.submit()">
            <option value="alphabetical" <?= (isset($_GET['sort']) && $_GET['sort'] === 'alphabetical') ? 'selected' : '' ?>>Alphabetical</option>
            <option value="newest" <?= (isset($_GET['sort']) && $_GET['sort'] === 'newest') ? 'selected' : '' ?>>Newest</option>
            <option value="oldest" <?= (isset($_GET['sort']) && $_GET['sort'] === 'oldest') ? 'selected' : '' ?>>Oldest</option>
        </select>
    </form>

    <table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Type</th>
                <th>Message</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($contacts)): ?>
                <?php foreach ($contacts as $contact): ?>
                    <tr>
                        <td><?= htmlspecialchars($contact['name']) ?></td>
                        <td><?= htmlspecialchars($contact['email']) ?></td>
                        <td><?= htmlspecialchars($contact['type']) ?></td>
                        <td><?= htmlspecialchars($contact['message']) ?></td>
                        <td><?= htmlspecialchars($contact['status']) ?></td>
                        <td>
                            <a href="?action=approve&id=<?= $contact['id'] ?>">Approve</a>
                            <a href="?action=disapprove&id=<?= $contact['id'] ?>">Decline</a>
                            <a href="?action=edit&id=<?= $contact['id'] ?>">Edit</a>
                            <a href="?action=delete&id=<?= $contact['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No messages found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
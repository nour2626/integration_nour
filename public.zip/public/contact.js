document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("contactForm");

    // Form fields and error messages
    const nameField = document.getElementById("name");
    const emailField = document.getElementById("email");
    const messageField = document.getElementById("message");
    const nameError = document.getElementById("nameError");
    const emailError = document.getElementById("emailError");
    const messageError = document.getElementById("messageError");

    // Regular expression for email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // List of banned words
    const bannedWords = ["fuck", "badword", "zute"];

    // Real-time validation for the name field
    nameField.addEventListener("input", () => {
        if (!nameField.value.trim()) {
            nameError.textContent = "Name is required.";
            nameError.style.display = "block";
        } else if (nameField.value.length > 20) {
            nameError.textContent = "Name cannot exceed 20 characters.";
            nameError.style.display = "block";
        } else {
            nameError.style.display = "none";
        }
    });

    // Real-time validation for the email field
    emailField.addEventListener("input", () => {
        if (!emailField.value.trim()) {
            emailError.textContent = "Email is required.";
            emailError.style.display = "block";
        } else if (!emailRegex.test(emailField.value)) {
            emailError.textContent = "Please enter a valid email address.";
            emailError.style.display = "block";
        } else {
            emailError.style.display = "none";
        }
    });

    // Real-time validation for the message field
    messageField.addEventListener("input", () => {
        const currentValue = messageField.value;
        const lowerCaseValue = currentValue.toLowerCase();

        // Check for banned words
        const containsBannedWord = bannedWords.some((word) =>
            lowerCaseValue.includes(word)
        );

        if (containsBannedWord) {
            messageError.textContent = "Your message contains bad words >:(";
            messageError.style.color = "red";
            messageError.style.display = "block";
        } else {
            messageError.style.display = "none";
        }
    });

    // Prevent form submission on bad input
    form.addEventListener("submit", (e) => {
        const currentValue = messageField.value.toLowerCase();
        const containsBannedWord = bannedWords.some((word) =>
            currentValue.includes(word)
        );

        if (containsBannedWord) {
            e.preventDefault();
            messageError.textContent = "Please remove inappropriate words before submitting.";
            messageError.style.color = "red";
            messageError.style.display = "block";
        }
    });
});

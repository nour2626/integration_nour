document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const nameInput = form.querySelector('[name="name"]');
    const descriptionInput = form.querySelector('[name="description"]');
    const priceInput = form.querySelector('[name="price"]');
    const destinationInput = form.querySelector('[name="destination"]');

    const nameError = form.querySelector('#nameError');
    const priceError = form.querySelector('#priceError');
    const destinationError = form.querySelector('#destinationError');

    const validDestinations = [
        "Tunis", "Sousse", "Sfax", "Kairouan", "Tozeur", "Djerba", "Monastir", "Nabeul", "Mahdia", "Bizerte", "Gabes", "tunis", "sousse", "sfax", "kairouan", "tozeur", "djerba", "monastir", "nabeul", "mahdia", "bizerte", "gabes"
    ]; // Example list of places in Tunisia

    // Real-time validation for name
    nameInput.addEventListener('input', function () {
        const name = nameInput.value.trim();
        if (name === '') {
            nameError.textContent = 'Name is required.';
        } else if (name.length > 20) {
            nameError.textContent = 'Name cannot exceed 20 characters.';
        } else {
            nameError.textContent = '';
        }
    });

    // Real-time validation for price
    priceInput.addEventListener('input', function () {
        const price = parseFloat(priceInput.value);
        if (price < 1 || price > 100) {
            priceError.textContent = 'Price must be between 1 and 100.';
        } else {
            priceError.textContent = '';
        }
    });

    // Real-time validation for destination
    destinationInput.addEventListener('input', function () {
        const destination = destinationInput.value.trim();
        if (!validDestinations.includes(destination)) {
            destinationError.textContent = 'Please enter a valid destination in Tunisia.';
        } else {
            destinationError.textContent = '';
        }
    });

    // Final validation on form submission
    form.addEventListener('submit', function (e) {
        let valid = true;

        // Name validation
        const name = nameInput.value.trim();
        if (name === '') {
            nameError.textContent = 'Name is required.';
            valid = false;
        } else if (name.length > 20) {
            nameError.textContent = 'Name cannot exceed 20 characters.';
            valid = false;
        }

        // Price validation
        const price = parseFloat(priceInput.value);
        if (price < 1 || price > 100) {
            priceError.textContent = 'Price must be between 1 and 100.';
            valid = false;
        }

        // Destination validation
        const destination = destinationInput.value.trim();
        if (!validDestinations.includes(destination)) {
            destinationError.textContent = 'Please enter a valid destination in Tunisia.';
            valid = false;
        }

        // If any validation failed, prevent form submission
        if (!valid) {
            e.preventDefault();
        }
    });
});

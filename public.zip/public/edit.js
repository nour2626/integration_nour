document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const nameInput = form.querySelector('[name="name"]');
    const emailInput = form.querySelector('[name="email"]');
    const messageInput = form.querySelector('[name="message"]');
    const statusSelect = form.querySelector('[name="status"]'); // optional if used for admin

    // Get the error message spans
    const nameError = document.getElementById('nameError');
    const emailError = document.getElementById('emailError');
    const messageError = document.getElementById('messageError');

    // Real-time validation for name
    nameInput.addEventListener('input', function () {
        const name = nameInput.value.trim();
        if (name === '') {
            nameError.textContent = 'Name is required.';
        } else if (name.length > 20) {
            nameError.textContent = 'Name should be less than 20 characters.';
        } else {
            nameError.textContent = '';
        }
    });

    // Real-time validation for email
    emailInput.addEventListener('input', function () {
        const email = emailInput.value.trim();
        if (email === '') {
            emailError.textContent = 'Email is required.';
        } else if (!email.includes('@')) {
            emailError.textContent = 'Email should contain "@" symbol.';
        } else {
            emailError.textContent = '';
        }
    });

    // Real-time validation for message
    messageInput.addEventListener('input', function () {
        const message = messageInput.value.trim();
        if (message === '') {
            messageError.textContent = 'Message is required.';
        } else {
            messageError.textContent = '';
        }
    });

    // Final validation on form submission
    form.addEventListener('submit', function (e) {
        let valid = true;

        // Name validation
        const name = nameInput.value.trim();
        if (name === '') {
            nameError.textContent = 'Name is required.';
            valid = false;
        } else if (name.length > 20) {
            nameError.textContent = 'Name should be less than 20 characters.';
            valid = false;
        }

        // Email validation
        const email = emailInput.value.trim();
        if (email === '') {
            emailError.textContent = 'Email is required.';
            valid = false;
        } else if (!email.includes('@')) {
            emailError.textContent = 'Email should contain "@" symbol.';
            valid = false;
        }

        // Message validation
        const message = messageInput.value.trim();
        if (message === '') {
            messageError.textContent = 'Message is required.';
            valid = false;
        }

        // If any validation failed, prevent form submission
        if (!valid) {
            e.preventDefault();
        }
    });
});

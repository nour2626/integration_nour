<?php
require_once __DIR__ . '/../public/src/PHPMailer.php';
require_once __DIR__ . '/../public/src/SMTP.php';
require_once __DIR__ . '/../public/src/Exception.php';

require_once __DIR__ . '/../model/ContactModel.php';

class Controller {
    private $model;

    public function __construct() {
        $this->model = new ContactModel();
    }

    public function handleRequest() {
        $action = $_GET['action'] ?? 'form';

        switch ($action) {
            case 'form':
                $this->showForm(); 
                break;
            case 'create':
                $this->createContact();
                break;
            case 'updateStatus':
                $this->updateStatus();
                break;
            case 'approve':
                $this->approveContact();
                break;
            case 'disapprove':
                $this->disapproveContact();
                break;
            case 'list':
                $this->manageMessages();
                break;
            case 'edit':
                $this->editContact();
                break;
            case 'delete':
                $this->deleteContact();
                break;
            default:
                $this->showDashboard();
        }
    }

    private function showForm() {
        include __DIR__ . '/../index1.php';
    }

    private function createContact() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'type' => $_POST['type'],
                'message' => $_POST['message']
            ];
            if ($this->model->create($data)) {
                header("Location: ?action=list");
                exit;
            } else {
                echo "Failed to save the contact message!";
            }
        }
    }

    private function manageMessages() {
        
        $contacts = $this->model->getAll();
        include __DIR__ . '/../view/contact_list.php';
    }

    private function approveContact() {
        $id = $_GET['id'] ?? null;
    
        if ($id) {
            $contact = $this->model->getById($id);
            if ($contact && $this->model->updateStatus($id, 'approved')) {
                // Send approval email
                $this->sendApprovalEmail($contact['email'], $contact['name']);
                
                header("Location: ?action=list");
                exit;
            } else {
                echo "Failed to update status.";
            }
        } else {
            echo "Invalid request.";
        }
    }
    
    private function disapproveContact() {
        $id = $_GET['id'] ?? null;
    
        if ($id) {
            $contact = $this->model->getById($id);
            if ($contact && $this->model->updateStatus($id, 'disapproved')) {
                // Send disapproval email
                $this->sendDisapprovalEmail($contact['email'], $contact['name']);
                
                header("Location: ?action=list");
                exit;
            } else {
                echo "Failed to update status.";
            }
        } else {
            echo "Invalid request.";
        }
    }
    private function sendApprovalEmail($email, $name) {
        $subject = "Your Message Has Been Approved";
        $message = "Dear $name,\n\nYour submitted message has been reviewed and approved.\n\nThank you for reaching out to us.\n\nBest regards,\nYour Company Name";
        $headers = "From: no-reply@yourdomain.com" . "\r\n" .
                   "Reply-To: support@yourdomain.com" . "\r\n" .
                   "X-Mailer: PHP/" . phpversion();
    
        if (!mail($email, $subject, $message, $headers)) {
            echo "Failed to send the approval email.";
        }
    }
    
    private function sendDisapprovalEmail($email, $name) {
        $subject = "Your Message Has Been Declined";
        $message = "Dear $name,\n\nWe regret to inform you that your submitted message has been reviewed and declined.\n\nThank you for reaching out to us.\n\nBest regards,\nYour Company Name";
        $headers = "From: no-reply@yourdomain.com" . "\r\n" .
                   "Reply-To: support@yourdomain.com" . "\r\n" .
                   "X-Mailer: PHP/" . phpversion();
    
        if (!mail($email, $subject, $message, $headers)) {
            echo "Failed to send the disapproval email.";
        }
    }
    private function editContact() {
        $id = $_GET['id'] ?? null;
        if ($id && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'type' => $_POST['type'],
                'message' => $_POST['message']
            ];

            if ($this->model->update($id, $data)) {
                header("Location: ?action=list");
                exit;
            } else {
                echo "Failed to update the message.";
            }
        } else {
            $contact = $this->model->getById($id);
            include __DIR__ . '/../view/edit_contact.php';
        }
    }

    private function deleteContact() {
        $id = $_GET['id'] ?? null;
        if ($id && $this->model->delete($id)) {
            header("Location: ?action=list");
            exit;
        } else {
            echo "Failed to delete the message.";
        }
    }

    private function showDashboard() {
        include __DIR__ . '/../index1.php'; 
    }
}
?>
